const express = require('express');
const session = require('express-session');
const cookieSession = require('cookie-session')
const http = require('http');
const bodyParser = require('body-parser');
const url = require('url');
const router = express.Router();
const app = express();



/*app.use(bodyParser.text({
  type: function(req) {
    return 'text';
  }
}));*/

app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ secret: 'hachiroku', cookie: { secure: false }}))

cookie: { secure: false }



var sess;

app.get("/", (req, res) => {
  res.send("Get request noted")

  console.log("Session ID: " + req.sessionID)

})

app.post("/", (req, res) => {
  console.log("Post request noted")

  //Here is showing your URL
  var myURL = req.originalUrl;
  console.log("URL: " + myURL)

  //Here is showing your ID
  var sess = req.sessionID;
  console.log("Session ID: " + sess)

  res.send("Post request received")
})

//running server here
http.createServer(app).listen(3000, () => {
  console.log("Server listening at port 3000")

});