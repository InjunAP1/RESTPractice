index.js
Run these 2 commands before texting on 2 separate terminals:
ssh -R becauseracecar:80:localhost:3000 serveo.net
node index.js

Now text 3602153164# RESTPractice
