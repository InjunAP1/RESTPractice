//Not related to twilio, this is a separate test piece of code
const express = require('express');
const { request, response } = require('../../app');
const router = express.Router();


router.get('/', (req, res, next) => {
    res.status(200).json({
        meesage: 'Handling GET requests to /products'
    });
});

router.post('/', (req, res, next) => {
    res.status(200).json({
        meesage: 'Handling POST requests to /products'
    });
});

router.get('/:productId', (req, res, next) => {
    const id = req.params.productId;
    if (id == 'special') {
        res.status(200).json({
            message: 'You discovered the special ID',
            id: id
        });
    }
    else {
        res.status(200).json({
            message: `You passed an ID`
        });
    }
});





module.exports = router;