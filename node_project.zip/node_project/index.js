const express = require('express');
const MessagingResponse = require('twilio').twiml.MessagingResponse;

const app = express();

app.get('/', (req, res) => {
  res.send('Hello World!');
});

app.post('/sms', (req, res) => {

  // Start twiml response.
  const twiml = new MessagingResponse();

  // Send txt
  const msg = twiml.message('Check out this Area 51 meme I spent way too much time making!');

  // Add picture
  msg.media('https://i.redd.it/hzm3yg35mtn31.png');

  res.writeHead(200, {'Content-Type': 'text/xml'});
  res.end(twiml.toString());
});

app.listen(3000, () => {
  console.log('Example app listening on port 3000!');
});